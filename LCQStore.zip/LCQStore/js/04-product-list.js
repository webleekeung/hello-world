(()=>{
ajax("get","data/floor.php","")
.then(output=>{
		//根据规定的模板,动态生成f1的HTML代码片段
    var html="";
    var f1=output.f1;

    for(var i=0;i<f1.length;i++){
      var p=f1[i];
	  html+=`
			<li>
			  <a href="${p.href}">
				<img src="${p.pic}"/>
			  </a>
			  <a href="${p.href}">${p.details}</a><br/>
			  <span>本店售价：${parseFloat(p.price).toFixed(2)}</span>
			</li>`
	    }
		document.getElementById("l1")
            .innerHTML=html;
		document.getElementById("l2")
            .innerHTML=html;
		document.getElementById("l3")
            .innerHTML=html;
	});
})();