(()=>{
$("#header").load("01-header.html",()=>{
	var $login=$("#listLogin"),
        $welcome=$("#listWelcome");
	$.get("data/isLogin.php")
    .then(data=>{
		  if(data.ok===1){
			$("#uname").text(data.uname);
			$welcome.show();
			$login.hide();
		  }else{
			$welcome.hide();
			$login.show();
		  }
		});
	});	
$("#nav").load("05-nav.html",()=>{
	//再实现鼠标移入下拉
		//为data-trigger属性为dropdown的父元素绑定鼠标进入事件
		$("[data-trigger=dropdown]").parent()
		  .mouseover(
		  function(){
			var $li=$(this);
					//查找div的直接子元素中最后一个
			var $menu=$li.children().last();
			$menu.css({height:250,opacity:1});
		  }
		).mouseout(function(){
		//继续为data-trigger属性为dropdown的父元素绑定鼠标移出事件
		  var $li=$(this);
		  var $menu=$li.children().last();
		  $menu.css({height:0,opacity:0});
		});
})
})();