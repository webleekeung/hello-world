(function($){
	$.fn.createPage = function(options){
        var args = $.extend({
            pageCount : 6,
            current : 1,
            backFn : function(){}
        },options);
        ms.init(this,args);
    }
})(jQuery);