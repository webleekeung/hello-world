(()=>{
	$("#footer").load("02-footer.html");
})();