SET NAMES UTF8;
DROP DATABASE IF EXISTS ss;
CREATE DATABASE ss CHARSET=UTF8;
USE ss;

/**服装类型家族**/
CREATE TABLE ss_clothes_family(
  fid INT PRIMARY KEY AUTO_INCREMENT,
  fname VARCHAR(32)
);

/**服装类型详情**/
CREATE TABLE ss_clothes(
  lid INT PRIMARY KEY AUTO_INCREMENT,
  family_id INT,              #所属服装类型家族编号
  title VARCHAR(128),         #主标题
  price DECIMAL(10,2),        #价格
  spec VARCHAR(64),           #颜色
  size VARCHAR(8),	      #尺寸

  inventory INT,              #商品库存
  brand VARCHAR(16),          #商品品牌
  weight VARCHAR(16),         #商品重量
  hits INT                    #商品点击数
);

/**服装图片**/
CREATE TABLE ss_clothes_pic(
  pid INT PRIMARY KEY AUTO_INCREMENT,
  clothes_id INT,              #服装编号
  sm VARCHAR(128),            #小图片路径
  md VARCHAR(128),            #中图片路径
  lg VARCHAR(128)             #大图片路径
);

/**用户信息**/
CREATE TABLE ss_user(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(32),
  upwd VARCHAR(32),
  email VARCHAR(64),
  phone VARCHAR(16),

  user_name VARCHAR(32),      #用户名，如王小明
  gender INT                  #性别  0-女  1-男
);

/**收货地址信息**/
CREATE TABLE ss_receiver_address(
  aid INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,                #用户编号
  receiver VARCHAR(16),       #接收人姓名
  province VARCHAR(16),       #省
  city VARCHAR(16),           #市
  county VARCHAR(16),         #县
  address VARCHAR(128),       #详细地址
  cellphone VARCHAR(16),      #手机
  fixedphone VARCHAR(16),     #固定电话
  postcode CHAR(6),           #邮编
  tag VARCHAR(16),            #标签名

  is_default BOOLEAN          #是否为当前用户的默认收货地址
);

/**购物车条目**/
CREATE TABLE ss_shoppingcart_item(
  iid INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,      #用户编号
  product_id INT,   #商品编号
  count INT,        #购买数量
  is_checked BOOLEAN #是否已勾选，确定购买
);

/**用户订单**/
CREATE TABLE ss_order(
  aid INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  address_id INT,
  status INT,             #订单状态  1-等待付款  2-等待发货  3-运输中  4-已签收  5-已取消
  order_time BIGINT,      #下单时间
  pay_time BIGINT,        #付款时间
  deliver_time BIGINT,    #发货时间
  received_time BIGINT    #签收时间
)AUTO_INCREMENT=10000000;

/**用户订单**/
CREATE TABLE ss_order_detail(
  did INT PRIMARY KEY AUTO_INCREMENT,
  order_id INT,           #订单编号
  product_id INT,         #产品编号
  count INT               #购买数量
);

/****首页轮播广告商品****/
CREATE TABLE ss_index_carousel(
  cid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128),
  title VARCHAR(64),
  href VARCHAR(128)
);

/****首页商品****/
CREATE TABLE ss_index_product(
  pid INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(64),
  details VARCHAR(128),
  pic VARCHAR(128),
  price DECIMAL(10,2),
  href VARCHAR(128),
  seq_recommended TINYINT,
  seq_new_arrival TINYINT,
  seq_top_sale TINYINT
);

/*******************/
/******数据导入******/
/*******************/
/**用户信息**/
INSERT INTO ss_user VALUES
(NULL, 'baobao', '123456', 'bao@qq.com', '13501234567', '宝宝', '1'),
(NULL, 'beibei', '123456', 'bei@qq.com', '13501234568', '贝贝', '1'),
(NULL, 'zhuzhu', '123456', 'zhu@qq.com', '13501234569', '猪猪', '1'),
(NULL, 'guaiguai', '123456', 'guai@qq.com', '13501234560', '乖乖', '0');

/****首页轮播广告商品****/
INSERT INTO ss_index_carousel VALUES
(NULL, 'images/20170523elfvwi.jpg','轮播广告商品1','03-index.html'),
(NULL, 'images/20170523ojbhgm.jpg','轮播广告商品2','03-index.html'),
(NULL, 'images/20170523pvxtgm.jpg','轮播广告商品3','03-index.html'),
(NULL, 'images/20170523qmqoqd.jpg','轮播广告商品4','03-index.html'),
(NULL, 'images/20170523vemshr.jpg','轮播广告商品5','03-index.html');

/****首页商品****/
INSERT INTO ss_index_product VALUES
(NULL, '连衣裙', '2017春装新款女装韩版时尚显瘦长袖a字裙春秋款性感一字肩连衣裙', 'images/tb1alpbppxxxxchxfxxxxxxxxxx_!!0-item_pic.jpg_300x300.jpg', 188.00, '03-index.html', 1, 6, 0),
(NULL, '大摆裙', '2017春季新款A字短裙百搭时尚显瘦高腰半身裙双口袋大摆裙女', 'images/tb1cg9ppvxxxxcbxvxxxxxxxxxx_!!0-item_pic.jpg_300x300.jpg', 49.90, '03-index.html', 2, 0, 5),
(NULL, '雪纺衫', '春夏装新款女装韩范时尚印花两件套装短袖雪纺衫/短裤2件套装', 'images/tb1lvvpmxxxxxa4xpxxxxxxxxxx_!!0-item_pic.jpg_300x300.jpg', 88.00, '03-index.html', 3, 5, 4),
(NULL, '体恤', '女装春装2017新款潮短袖t恤女宽松字母上衣女打底衫学生女士体恤', 'images/tb1rffspvxxxxxaxfxxxxxxxxxx_!!0-item_pic.jpg_300x300.jpg', 59.00, '03-index.html', 4, 4, 3),
(NULL, '打底裙', '2017夏款森女松紧收腰短袖碎花雪纺连衣裙女中长款百褶打底裙百搭', 'images/tb1e9fbqpxxxxb_xvxxxxxxxxxx_!!0-item_pic.jpg_300x300.jpg', 49.90, '03-index.html', 5, 2, 1),
(NULL, '百褶打底裙', '2017夏款森女松紧收腰短袖碎花雪纺连衣裙女中长款百褶打底裙百搭', 'images/tb1f8dvrpxxxxxexfxxxxxxxxxx_!!0-item_pic.jpg_300x300.jpg', 49.90, '03-index.html', 6, 3, 2),
(NULL, '短袖体恤', '女装春装2017新款潮白色t恤女中长袖韩版上衣V领打底短袖体恤女夏', 'images/tb1eosbqpxxxxxpxxxxxxxxxxxx_!!0-item_pic.jpg_300x300.jpg', 79.90, '03-index.html', 7, 1, 6),
(NULL, '蓬蓬短裙', '夏装新款雪纺半身裙百褶a字裙子韩版高腰显瘦百搭网纱蓬蓬短裙女', 'images/tb1e7g1qfxxxxxcxvxxxxxxxxxx_!!0-item_pic.jpg_300x300.jpg', 60.00, '03-index.html', 8, 7, 8),
(NULL, '小衫', '短袖t恤女白色上衣宽松打底衫女夏装韩版印花个性小衫2017新款潮', 'images/tb1grsvqpxxxxaxafxxxxxxxxxx_!!0-item_pic.jpg_300x300.jpg', 59.00, '03-index.html', 9, 8, 9),
(NULL, '短裙', '莜原2017春夏新款韩版印花高腰半身裙小清新A字裙短裙女镶钻装饰', 'images/tb1duwupfxxxxacxvxxxxxxxxxx_!!0-item_pic.jpg_300x300.jpg', 76.00, '03-index.html', 0, 9, 7);
















